package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

@TeleOp(name = "drivetest", group = "LinearOpmode")
public class drivetest extends LinearOpMode {

    private ElapsedTime runtime = new ElapsedTime();
    private DcMotor leftFrontDrive = null;
    private DcMotor leftBackDrive = null;
    private DcMotor rightFrontDrive = null;
    private DcMotor rightBackDrive = null;
    private DcMotor armdrive = null;
    private DcMotor viperSlideMotor = null; // Declare the motor

    private Servo claw; // Servo object for claw
    private Servo tilt; // Servo object for tilt

    private boolean reverseControls = false;
    private double leftFrontPower, rightFrontPower, leftBackPower, rightBackPower;

    // Constants for servo positions
    private static final double CLOSD = 0.577;
    private static final double OPEN = 0.48;
    private static final double STARTTILT = 0.353;
    private static final double UPTILT = 0.5;
    private static final double DOWNTILT = 0.3;

    private boolean clawopen = true;
    private boolean clawlaststate = true;
    private int targetPosition = 0;

    // Power limits for viperSlideMotor
    private static final double POWER_UP = 1.7;  // Upward power
    private static final double POWER_DOWN = -1.7; // Downward power
    private static final double STOP_POWER = 0.0;

    private void initialize() {
        telemetry.addData("Status", "Initialized");
        telemetry.update();

        waitForStart();
        runtime.reset();
    }

    private void initialize_mechanum() {
        leftFrontDrive = hardwareMap.get(DcMotor.class, "frontLeft");
        leftBackDrive = hardwareMap.get(DcMotor.class, "backLeft");
        rightFrontDrive = hardwareMap.get(DcMotor.class, "frontRight");
        rightBackDrive = hardwareMap.get(DcMotor.class, "backRight");
        armdrive = hardwareMap.get(DcMotor.class, "arm");
        viperSlideMotor = hardwareMap.get(DcMotor.class, "viperSlideMotor"); // Initialize viperSlideMotor

        claw = hardwareMap.get(Servo.class, "claw");
        tilt = hardwareMap.get(Servo.class, "tilt");

        claw.setPosition(OPEN);
        tilt.setPosition(STARTTILT);

        leftFrontDrive.setDirection(DcMotor.Direction.FORWARD);
        leftBackDrive.setDirection(DcMotor.Direction.FORWARD);
        rightFrontDrive.setDirection(DcMotor.Direction.REVERSE);
        rightBackDrive.setDirection(DcMotor.Direction.REVERSE);

        armdrive.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        armdrive.setTargetPosition(targetPosition);
        armdrive.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        viperSlideMotor.setDirection(DcMotorSimple.Direction.FORWARD); // Set motor direction
        viperSlideMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE); // Set zero power behavior
    }

    private void run_mechanum() {
        double max;
        double axial = (reverseControls ? -gamepad1.left_stick_y : gamepad1.left_stick_y);
        double lateral = -(reverseControls ? -gamepad1.left_stick_x : gamepad1.left_stick_x);
        double yaw = gamepad1.right_stick_x;

        leftFrontPower = axial + lateral + yaw;
        rightFrontPower = axial - lateral - yaw;
        leftBackPower = axial - lateral + yaw;
        rightBackPower = axial + lateral - yaw;

        max = Math.max(Math.abs(leftFrontPower), Math.abs(rightFrontPower));
        max = Math.max(max, Math.abs(leftBackPower));
        max = Math.max(max, Math.abs(rightBackPower));

        if (max > 1.0) {
            leftFrontPower /= max;
            rightFrontPower /= max;
            leftBackPower /= max;
            rightBackPower /= max;
        }
    }

    private void run_mechanum_speed() {
        if (gamepad1.left_stick_button) {
            leftFrontDrive.setPower(leftFrontPower / -0.001);
            rightFrontDrive.setPower(rightFrontPower / -0.001);
            leftBackDrive.setPower(leftBackPower / -0.001);
            rightBackDrive.setPower(rightBackPower / -0.001);
        } else {
            leftFrontDrive.setPower(leftFrontPower);
            rightFrontDrive.setPower(rightFrontPower);
            leftBackDrive.setPower(leftBackPower);
            rightBackDrive.setPower(rightBackPower);
        }
    }

    private void initialize_reverse() {
        reverseControls = false; // Variable to track whether controls are reversed
    }

    private void run_reverse() {
        if (gamepad1.a) {
            reverseControls = false;
        } else if (gamepad1.y) {
            reverseControls = true;
        }
    }

    private void run_arm() {
        double power = -gamepad2.right_stick_y;
        double powerFactor = 4.5;
        targetPosition += (int) Math.round(power * powerFactor);

        int maxPosition = 3557;
        int minPosition = 0;
        targetPosition = Math.max(minPosition, Math.min(maxPosition, targetPosition));

        armdrive.setTargetPosition(targetPosition);
        armdrive.setPower(0.5); // 0.5 equals the max speed of the arm

        boolean currentButtonState = gamepad2.a;
        if (currentButtonState && !clawlaststate) {
            clawopen = !clawopen; // Toggle claw state

            if (clawopen) {
                claw.setPosition(OPEN);
            } else {
                claw.setPosition(CLOSD);
            }
            telemetry.addData("Claw", clawopen ? "Open" : "Closed");
            telemetry.update();
        }
        clawlaststate = currentButtonState;
    }

    private void run_viper_slide() {
        if (gamepad2.dpad_up) {
            viperSlideMotor.setPower(POWER_UP); // Move upward
        } else if (gamepad2.dpad_down) {
            viperSlideMotor.setPower(POWER_DOWN); // Move downward
        } else {
            viperSlideMotor.setPower(STOP_POWER); // Stop the motor
        }
        telemetry.addData("Viper Slide Motor Power", viperSlideMotor.getPower());
    }

    private void updateTelemetry() {
        telemetry.addData("Status", "Run Time: " + runtime.toString());
        telemetry.addData("Front left/Right", "%4.2f, %4.2f", leftFrontPower, rightFrontPower);
        telemetry.addData("Back left/Right", "%4.2f, %4.2f", leftBackPower, rightBackPower);
        telemetry.addData("Reverse Controls", reverseControls ? "Reversed" : "Normal");
        telemetry.addData("Encoder Ticks Arm", armdrive.getCurrentPosition());
        telemetry.addData("Claw Open", claw.getPosition() == OPEN);
        telemetry.update();
    }

    @Override
    public void runOpMode() {
        initialize();
        initialize_reverse();
        initialize_mechanum();

        while (opModeIsActive()) {
            run_reverse();
            run_mechanum();
            run_mechanum_speed();
            run_arm();
            run_viper_slide();
            updateTelemetry();
        }
    }
}

